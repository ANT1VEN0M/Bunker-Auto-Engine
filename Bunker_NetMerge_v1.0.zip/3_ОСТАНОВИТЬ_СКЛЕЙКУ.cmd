@echo off
chcp 65001 >nul
title Бункер Net-Merge: Остановка склейки
cls
cd /d "%~dp0"
echo =====================================================================
echo       🐈‍⬛ БУНКЕР NET-MERGE: ОСТАНОВКА И ОЧИСТКА МАРШРУТОВ
echo =====================================================================
echo.
echo [*] Остановка фоновой службы...
net-merge.exe off >nul 2>&1
net-merge.exe quit >nul 2>&1
taskkill /F /IM net-merge-tray.exe >nul 2>&1
taskkill /F /IM net-merge.exe >nul 2>&1
net-merge.exe cleanup >nul 2>&1

echo.
echo [OK] Склейка остановлена. Все стандартные сетевые маршруты восстановлены!
echo.
timeout /t 3 >nul
exit
