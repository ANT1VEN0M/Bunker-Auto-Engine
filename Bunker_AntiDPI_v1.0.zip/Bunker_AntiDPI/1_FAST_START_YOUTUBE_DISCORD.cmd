@echo off
setlocal
chcp 65001 > nul
title Bunker Anti-DPI (Быстрый запуск)

:: Проверка прав администратора
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath cmd.exe -ArgumentList '/k ""%~f0""' -Verb RunAs"
    exit /b
)

pushd "%~dp0"
set "ROOT=%~dp0"
taskkill /F /IM winws.exe >nul 2>&1

echo [i] Запуск Bunker Anti-DPI (YouTube 4K + Discord)...
echo [!] НЕ ЗАКРЫВАЙТЕ ЭТО ОКНО! Сверните его во время использования.
echo.

pushd "%ROOT%bin"
start "Bunker Anti-DPI [Active]" /min winws.exe --wf-tcp=80,443,2053,2083,2087,2096,8443 --wf-udp=443,19294-19344,50000-50100 --filter-udp=443 --hostlist="..\lists\list-general.txt" --dpi-desync=fake --dpi-desync-repeats=11 --dpi-desync-fake-quic="quic_initial_www_google_com.bin" --new --filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-fake-discord="ACTIVE_DISCORD_UDP.bin" --dpi-desync-fake-stun="ACTIVE_DISCORD_UDP.bin" --dpi-desync-repeats=6 --new --filter-tcp=2053,2083,2087,2096,8443 --hostlist-domains=discord.media --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=681 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern="tls_clienthello_www_google_com.bin" --dpi-desync-fake-tls="tls_clienthello_www_google_com.bin" --new --filter-tcp=443 --hostlist="..\lists\list-google.txt" --ip-id=zero --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=681 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern="tls_clienthello_www_google_com.bin" --dpi-desync-fake-tls="tls_clienthello_www_google_com.bin" --new --filter-tcp=80,443 --hostlist="..\lists\list-general.txt" --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=664 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern="tls_clienthello_www_sferum_ru.bin" --dpi-desync-fake-tls="stun2.bin"
popd

echo [✓] Bunker Anti-DPI успешно запущен! Сверните это окно.
popd
pause
