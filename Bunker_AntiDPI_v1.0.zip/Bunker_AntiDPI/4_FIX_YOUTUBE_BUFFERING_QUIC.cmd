@echo off
setlocal
chcp 65001 > nul
title Устранение буферизации YouTube (Отключение QUIC)

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Требуются права Администратора...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

echo ===============================================================================
echo   Устранение зависания и буферизации YouTube (Отключение QUIC UDP 443)
echo ===============================================================================
echo.
echo [i] ТСПУ в РФ душит протокол QUIC (UDP:443) на видеосерверах YouTube до 144p.
echo [i] Это правило брандмауэра принудительно переключает браузеры на чистый TCP TLS,
echo [i] на котором Bunker Anti-DPI выдает мгновенный 4K без задержек.
echo.

netsh advfirewall firewall delete rule name="Bunker-Block-QUIC-UDP443" >nul 2>&1
netsh advfirewall firewall add rule name="Bunker-Block-QUIC-UDP443" dir=out action=block protocol=UDP remoteport=443 >nul 2>&1

if %errorlevel% equ 0 (
    echo [OK] Защитное правило брандмауэра успешно активировано!
    echo.
    echo ===============================================================================
    echo [!] ЧТО СДЕЛАТЬ СЕЙЧАС:
    echo 1. Полностью закройте браузер (Chrome / Edge / Yandex / Opera) и откройте снова.
    echo 2. Запустите 1_FAST_START_YOUTUBE_DISCORD.cmd или ALT_START_CRIMEA_SEVSTAR.cmd.
    echo 3. Включите видео на YouTube -- 4K 60fps теперь запускается моментально!
    echo ===============================================================================
) else (
    echo [X] Ошибка добавления правила брандмауэра.
)
echo.
pause
