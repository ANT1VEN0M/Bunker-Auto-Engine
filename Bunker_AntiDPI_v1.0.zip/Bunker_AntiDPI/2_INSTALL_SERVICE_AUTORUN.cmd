@echo off
setlocal
chcp 65001 > nul
title Установка службы Bunker Anti-DPI

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Требуются права Администратора...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"
set "BIN=%~dp0bin\"
set "LISTS=%~dp0lists\"
set "SRVCNAME=BunkerAntiDPI"

echo [i] Остановка старых процессов и служб...
net stop %SRVCNAME% >nul 2>&1
sc delete %SRVCNAME% >nul 2>&1
taskkill /F /IM winws.exe >nul 2>&1

set "BIN_EXE=%BIN%winws.exe"
set "LIST_GEN=%LISTS%list-general.txt"
set "LIST_GOOG=%LISTS%list-google.txt"
set "FAKE_QUIC=%BIN%quic_initial_www_google_com.bin"
set "FAKE_DISC=%BIN%ACTIVE_DISCORD_UDP.bin"
set "FAKE_TLS=%BIN%tls_clienthello_www_google_com.bin"
set "FAKE_SFER=%BIN%tls_clienthello_www_sferum_ru.bin"
set "FAKE_STUN=%BIN%stun2.bin"

echo [i] Создание службы Windows...
sc create %SRVCNAME% binPath= "\"\"%BIN_EXE%\" --wf-tcp=80,443,2053,2083,2087,2096,8443 --wf-udp=443,19294-19344,50000-50100 --filter-udp=443 --hostlist=\"%LIST_GEN%\" --dpi-desync=fake --dpi-desync-repeats=11 --dpi-desync-fake-quic=\"%FAKE_QUIC%\" --new --filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-fake-discord=\"%FAKE_DISC%\" --dpi-desync-repeats=6 --new --filter-tcp=443 --hostlist=\"%LIST_GOOG%\" --ip-id=zero --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=681 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern=\"%FAKE_TLS%\" --dpi-desync-fake-tls=\"%FAKE_TLS%\" --new --filter-tcp=80,443 --hostlist=\"%LIST_GEN%\" --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=664 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern=\"%FAKE_SFER%\" --dpi-desync-fake-tls=\"%FAKE_STUN%\"\"" DisplayName= "Bunker Anti-DPI Service" start= auto
sc description %SRVCNAME% "Фоновый обход блокировок ТСПУ для YouTube и Discord от Бункера Кота (@BUNKER_KOTA)"
sc start %SRVCNAME%

echo.
echo ===============================================================================
echo [OK] Служба «%SRVCNAME%» успешно установлена и запущена!
echo [i] Теперь обход работает в фоне и запускается автоматически вместе с Windows.
echo ===============================================================================
echo.
pause
