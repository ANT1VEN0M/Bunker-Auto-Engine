@echo off
title Установка службы Bunker Anti-DPI
chcp 65001 > nul
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)
cd /d "%~dp0"
set "BIN=%~dp0bin\"
set "LISTS=%~dp0lists\"
set "SRVCNAME=BunkerAntiDPI"

net stop %SRVCNAME% >nul 2>&1
sc delete %SRVCNAME% >nul 2>&1
taskkill /F /IM winws.exe >nul 2>&1

set "WINWS_BIN=%BIN%winws.exe"
set "ARGS=--wf-tcp=80,443,2053,2083,2087,2096,8443 --wf-udp=443,19294-19344,50000-50100 --filter-udp=443 --hostlist=\"%LISTS%list-general.txt\" --dpi-desync=fake --dpi-desync-repeats=11 --dpi-desync-fake-quic=\"%BIN%quic_initial_www_google_com.bin\" --new --filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-fake-discord=\"%BIN%ACTIVE_DISCORD_UDP.bin\" --dpi-desync-repeats=6 --new --filter-tcp=443 --hostlist=\"%LISTS%list-google.txt\" --ip-id=zero --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=681 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern=\"%BIN%tls_clienthello_www_google_com.bin\" --dpi-desync-fake-tls=\"%BIN%tls_clienthello_www_google_com.bin\" --new --filter-tcp=80,443 --hostlist=\"%LISTS%list-general.txt\" --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=664 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern=\"%BIN%tls_clienthello_www_sferum_ru.bin\" --dpi-desync-fake-tls=\"%BIN%stun2.bin\""

sc create %SRVCNAME% binPath= "\"%WINWS_BIN%\" %ARGS%" DisplayName= "Bunker Anti-DPI Service" start= auto
sc description %SRVCNAME% "Фоновый обход блокировок ТСПУ для YouTube и Discord от Бункера Кота (@BUNKER_KOTA)"
sc start %SRVCNAME%

echo.
echo ===============================================================================
echo [✓] Служба «%SRVCNAME%» успешно установлена и запущена!
echo [i] Теперь обход работает в фоне и запускается автоматически вместе с Windows.
echo ===============================================================================
pause
