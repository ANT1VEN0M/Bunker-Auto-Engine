@echo off
setlocal
chcp 65001 > nul
title Bunker Anti-DPI (Альтернативный режим: Крым / СевСтар / Ростелеком)

:: Проверка прав администратора
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath cmd.exe -ArgumentList '/k ""%~f0""' -Verb RunAs"
    exit /b
)

pushd "%~dp0"
set "ROOT=%~dp0"
taskkill /F /IM winws.exe >nul 2>&1

echo [i] Запуск Bunker Anti-DPI (Режим ALT-2: Multisplit pos=2)...
echo [i] Оптимизировано для провайдеров Крыма (СевСтар, Миранда) и Ростелеком.
echo [!] НЕ ЗАКРЫВАЙТЕ ЭТО ОКНО! Сверните его во время работы.
echo.

pushd "%ROOT%bin"
start "Bunker Anti-DPI [ALT-2 SevStar]" /min winws.exe --wf-tcp=80,443,2053,2083,2087,2096,8443 --wf-udp=443,19294-19344,50000-50100 --filter-udp=443 --hostlist="..\lists\list-general.txt" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-quic="quic_initial_www_google_com.bin" --new --filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-fake-discord="ACTIVE_DISCORD_UDP.bin" --dpi-desync-fake-stun="ACTIVE_DISCORD_UDP.bin" --dpi-desync-repeats=6 --new --filter-tcp=2053,2083,2087,2096,8443 --hostlist-domains=discord.media --dpi-desync=multisplit --dpi-desync-split-seqovl=652 --dpi-desync-split-pos=2 --dpi-desync-split-seqovl-pattern="tls_clienthello_www_google_com.bin" --new --filter-tcp=443 --hostlist="..\lists\list-google.txt" --ip-id=zero --dpi-desync=multisplit --dpi-desync-split-seqovl=652 --dpi-desync-split-pos=2 --dpi-desync-split-seqovl-pattern="tls_clienthello_www_google_com.bin" --new --filter-tcp=80,443 --hostlist="..\lists\list-general.txt" --dpi-desync=multisplit --dpi-desync-split-seqovl=652 --dpi-desync-split-pos=2 --dpi-desync-split-seqovl-pattern="tls_clienthello_www_google_com.bin"
popd

echo.
echo [✓] Обход активирован! Проверьте YouTube и Discord в браузере.
popd
pause
