@echo off
setlocal
chcp 65001 > nul
title Bunker Anti-DPI [Крым / СевСтар / Ростелеком]

:: Проверка прав администратора
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Требуются права Администратора...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"
set "BIN=%~dp0bin\"
set "LISTS=%~dp0lists\"

taskkill /F /IM winws.exe >nul 2>&1

echo ===============================================================================
echo   BUNKER ANTI-DPI v1.0.4  --  РЕЖИМ SEVSTAR / КРЫМ / РОСТЕЛЕКОМ
echo ===============================================================================
echo [i] Запуск специального пресета ALT-2 (Multisplit pos=2 без фейк-пакетов)...
echo [i] Оптимизировано под жесткие фильтры СевСтар (Севастополь), Миранда, Ростелеком.
echo [!] НЕ ЗАКРЫВАЙТЕ ЭТО ОКНО! Просто сверните его.
echo [i] Если видео долго буферизуется -- запустите «4_FIX_YOUTUBE_BUFFERING_QUIC.cmd»
echo.

cd /d "%BIN%"
start "Bunker Anti-DPI [SevStar Alt]" /min "%BIN%winws.exe" --wf-tcp=80,443,2053,2083,2087,2096,8443 --wf-udp=443,19294-19344,50000-50100 --filter-udp=443 --hostlist="%LISTS%list-general.txt" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-quic="%BIN%quic_initial_www_google_com.bin" --new --filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-fake-discord="%BIN%ACTIVE_DISCORD_UDP.bin" --dpi-desync-fake-stun="%BIN%ACTIVE_DISCORD_UDP.bin" --dpi-desync-repeats=6 --new --filter-tcp=2053,2083,2087,2096,8443 --hostlist-domains=discord.media --dpi-desync=multisplit --dpi-desync-split-seqovl=652 --dpi-desync-split-pos=2 --dpi-desync-split-seqovl-pattern="%BIN%tls_clienthello_www_google_com.bin" --new --filter-tcp=443 --hostlist="%LISTS%list-google.txt" --ip-id=zero --dpi-desync=multisplit --dpi-desync-split-seqovl=652 --dpi-desync-split-pos=2 --dpi-desync-split-seqovl-pattern="%BIN%tls_clienthello_www_google_com.bin" --new --filter-tcp=80,443 --hostlist="%LISTS%list-general.txt" --dpi-desync=multisplit --dpi-desync-split-seqovl=652 --dpi-desync-split-pos=2 --dpi-desync-split-seqovl-pattern="%BIN%tls_clienthello_www_google_com.bin"

echo.
echo [OK] Обход активирован! Проверьте YouTube и Discord в браузере.
echo.
pause
