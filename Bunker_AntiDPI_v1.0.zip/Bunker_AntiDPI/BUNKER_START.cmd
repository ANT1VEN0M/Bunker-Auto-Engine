@echo off
chcp 65001 > nul
title BUNKER ANTI-DPI v1.0.3 [KOT ANTIDOT]
color 0B

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Запрос прав Администратора...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"
set "BIN=%~dp0bin\"
set "LISTS=%~dp0lists\"
set "SRVCNAME=BunkerAntiDPI"

:MENU
cls
echo ===============================================================================
echo   BUNKER ANTI-DPI v1.0.3  --  ОБХОД БЛОКИРОВОК ТСПУ БЕЗ VPN
echo ===============================================================================
echo   Разработано: @k0tlux (KOT ANTIDOT)  •  Сообщество: @BUNKER_KOTA
echo   Поддержка: YouTube 4K 60fps, Discord (Голос/Видео/Медиа), Сайты
echo ===============================================================================
echo.
echo   [1] ЗАПУСТИТЬ: Режим «Ультра» (YouTube 4K + Discord Голос)
echo   [2] ЗАПУСТИТЬ: Режим «СевСтар / Крым / Ростелеком» (ALT-2 Multisplit)
echo   [3] ЗАПУСТИТЬ: Режим «ALT-1» (Fakedsplit - для провайдеров со строгим TCP)
echo   [4] УСТАНОВИТЬ В СЛУЖБЫ WINDOWS (Тихий автозапуск без открытых окон)
echo   [5] ОСТАНОВИТЬ ВСЕ ПРОЦЕССЫ И СЛУЖБУ
echo   [6] ДИАГНОСТИКА: Проверить доступ к YouTube и Discord
echo   [0] ВЫХОД
echo.
echo ===============================================================================
set /p choice="Выберите действие [0-6]: "

if "%choice%"=="1" goto START_ULTRA
if "%choice%"=="2" goto START_SEVSTAR
if "%choice%"=="3" goto START_ALT1
if "%choice%"=="4" goto INSTALL_SERVICE
if "%choice%"=="5" goto STOP_ALL
if "%choice%"=="6" goto TEST_CONNECTION
if "%choice%"=="0" goto QUIT
goto MENU

:START_ULTRA
cls
echo [i] Остановка предыдущих процессов winws...
taskkill /F /IM winws.exe >nul 2>&1
echo [i] Запуск Bunker Anti-DPI (Режим Ультра)...
echo.
echo [!] НЕ ЗАКРЫВАЙТЕ ЭТО ОКНО! Просто сверните его во время использования.
echo.
cd /d "%BIN%"
start "Bunker Anti-DPI [Ultra]" /min "%BIN%winws.exe" --wf-tcp=80,443,2053,2083,2087,2096,8443 --wf-udp=443,19294-19344,50000-50100 --filter-udp=443 --hostlist="%LISTS%list-general.txt" --dpi-desync=fake --dpi-desync-repeats=11 --dpi-desync-fake-quic="%BIN%quic_initial_www_google_com.bin" --new --filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-fake-discord="%BIN%ACTIVE_DISCORD_UDP.bin" --dpi-desync-fake-stun="%BIN%ACTIVE_DISCORD_UDP.bin" --dpi-desync-repeats=6 --new --filter-tcp=2053,2083,2087,2096,8443 --hostlist-domains=discord.media --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=681 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern="%BIN%tls_clienthello_www_google_com.bin" --dpi-desync-fake-tls="%BIN%tls_clienthello_www_google_com.bin" --new --filter-tcp=443 --hostlist="%LISTS%list-google.txt" --ip-id=zero --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=681 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern="%BIN%tls_clienthello_www_google_com.bin" --dpi-desync-fake-tls="%BIN%tls_clienthello_www_google_com.bin" --new --filter-tcp=80,443 --hostlist="%LISTS%list-general.txt" --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=664 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern="%BIN%tls_clienthello_www_sferum_ru.bin" --dpi-desync-fake-tls="%BIN%stun2.bin"
echo [OK] Обход активирован в фоновом окне! Проверьте YouTube и Discord.
echo.
pause
goto MENU

:START_SEVSTAR
cls
echo [i] Остановка предыдущих процессов winws...
taskkill /F /IM winws.exe >nul 2>&1
echo [i] Запуск Bunker Anti-DPI (Режим SevStar / Крым: Multisplit pos=2)...
echo.
echo [!] НЕ ЗАКРЫВАЙТЕ ЭТО ОКНО! Просто сверните его во время использования.
echo.
cd /d "%BIN%"
start "Bunker Anti-DPI [SevStar Alt]" /min "%BIN%winws.exe" --wf-tcp=80,443,2053,2083,2087,2096,8443 --wf-udp=443,19294-19344,50000-50100 --filter-udp=443 --hostlist="%LISTS%list-general.txt" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-quic="%BIN%quic_initial_www_google_com.bin" --new --filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-fake-discord="%BIN%ACTIVE_DISCORD_UDP.bin" --dpi-desync-fake-stun="%BIN%ACTIVE_DISCORD_UDP.bin" --dpi-desync-repeats=6 --new --filter-tcp=2053,2083,2087,2096,8443 --hostlist-domains=discord.media --dpi-desync=multisplit --dpi-desync-split-seqovl=652 --dpi-desync-split-pos=2 --dpi-desync-split-seqovl-pattern="%BIN%tls_clienthello_www_google_com.bin" --new --filter-tcp=443 --hostlist="%LISTS%list-google.txt" --ip-id=zero --dpi-desync=multisplit --dpi-desync-split-seqovl=652 --dpi-desync-split-pos=2 --dpi-desync-split-seqovl-pattern="%BIN%tls_clienthello_www_google_com.bin" --new --filter-tcp=80,443 --hostlist="%LISTS%list-general.txt" --dpi-desync=multisplit --dpi-desync-split-seqovl=652 --dpi-desync-split-pos=2 --dpi-desync-split-seqovl-pattern="%BIN%tls_clienthello_www_google_com.bin"
echo [OK] Альтернативный обход активирован!
echo.
pause
goto MENU

:START_ALT1
cls
echo [i] Остановка предыдущих процессов winws...
taskkill /F /IM winws.exe >nul 2>&1
echo [i] Запуск Bunker Anti-DPI (Режим ALT-1 Fakedsplit)...
echo.
echo [!] НЕ ЗАКРЫВАЙТЕ ЭТО ОКНО! Просто сверните его во время использования.
echo.
cd /d "%BIN%"
start "Bunker Anti-DPI [ALT-1]" /min "%BIN%winws.exe" --wf-tcp=80,443,2053,2083,2087,2096,8443 --wf-udp=443,19294-19344,50000-50100 --filter-udp=443 --hostlist="%LISTS%list-general.txt" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-quic="%BIN%quic_initial_www_google_com.bin" --new --filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-fake-discord="%BIN%ACTIVE_DISCORD_UDP.bin" --dpi-desync-fake-stun="%BIN%ACTIVE_DISCORD_UDP.bin" --dpi-desync-repeats=6 --new --filter-tcp=2053,2083,2087,2096,8443 --hostlist-domains=discord.media --dpi-desync=fake,fakedsplit --dpi-desync-repeats=6 --dpi-desync-fooling=ts --dpi-desync-fakedsplit-pattern=0x00 --dpi-desync-fake-tls="%BIN%tls_clienthello_www_google_com.bin" --new --filter-tcp=443 --hostlist="%LISTS%list-google.txt" --ip-id=zero --dpi-desync=fake,fakedsplit --dpi-desync-repeats=6 --dpi-desync-fooling=ts --dpi-desync-fakedsplit-pattern=0x00 --dpi-desync-fake-tls="%BIN%tls_clienthello_www_google_com.bin" --new --filter-tcp=80,443 --hostlist="%LISTS%list-general.txt" --dpi-desync=fake,fakedsplit --dpi-desync-repeats=6 --dpi-desync-fooling=ts --dpi-desync-fakedsplit-pattern=0x00 --dpi-desync-fake-tls="%BIN%stun.bin" --dpi-desync-fake-tls="%BIN%tls_clienthello_www_google_com.bin" --dpi-desync-fake-http="%BIN%tls_clienthello_www_sferum_ru.bin"
echo [OK] Режим ALT-1 активирован!
echo.
pause
goto MENU

:INSTALL_SERVICE
cls
echo ===============================================================================
echo   Установка службы Windows «%SRVCNAME%»
echo ===============================================================================
echo [i] Остановка старых служб и процессов...
net stop %SRVCNAME% >nul 2>&1
sc delete %SRVCNAME% >nul 2>&1
taskkill /F /IM winws.exe >nul 2>&1

set "BIN_EXE=%BIN%winws.exe"
set "LIST_GEN=%LISTS%list-general.txt"
set "LIST_GOOG=%LISTS%list-google.txt"
set "FAKE_QUIC=%BIN%quic_initial_www_google_com.bin"
set "FAKE_DISC=%BIN%ACTIVE_DISCORD_UDP.bin"
set "FAKE_TLS=%BIN%tls_clienthello_www_google_com.bin"
set "FAKE_SFER=%BIN%tls_clienthello_www_sferum_ru.bin"
set "FAKE_STUN=%BIN%stun2.bin"

echo [i] Создание службы Windows...
sc create %SRVCNAME% binPath= "\"\"%BIN_EXE%\" --wf-tcp=80,443,2053,2083,2087,2096,8443 --wf-udp=443,19294-19344,50000-50100 --filter-udp=443 --hostlist=\"%LIST_GEN%\" --dpi-desync=fake --dpi-desync-repeats=11 --dpi-desync-fake-quic=\"%FAKE_QUIC%\" --new --filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-fake-discord=\"%FAKE_DISC%\" --dpi-desync-repeats=6 --new --filter-tcp=443 --hostlist=\"%LIST_GOOG%\" --ip-id=zero --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=681 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern=\"%FAKE_TLS%\" --dpi-desync-fake-tls=\"%FAKE_TLS%\" --new --filter-tcp=80,443 --hostlist=\"%LIST_GEN%\" --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=664 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern=\"%FAKE_SFER%\" --dpi-desync-fake-tls=\"%FAKE_STUN%\"\"" DisplayName= "Bunker Anti-DPI Service" start= auto
sc description %SRVCNAME% "Фоновый обход блокировок ТСПУ для YouTube и Discord от Бункера Кота (@BUNKER_KOTA)"
sc start %SRVCNAME%

echo.
echo [OK] Служба «%SRVCNAME%» успешно установлена и запущена!
echo [i] Теперь обход будет работать автоматически при каждом включении ПК.
echo.
pause
goto MENU

:STOP_ALL
cls
echo [i] Остановка всех процессов и служб...
net stop %SRVCNAME% >nul 2>&1
sc delete %SRVCNAME% >nul 2>&1
net stop WinDivert >nul 2>&1
sc delete WinDivert >nul 2>&1
net stop WinDivert14 >nul 2>&1
sc delete WinDivert14 >nul 2>&1
taskkill /F /IM winws.exe >nul 2>&1
echo [OK] Все процессы Bunker Anti-DPI и служба успешно остановлены.
pause
goto MENU

:TEST_CONNECTION
cls
echo ===============================================================================
echo   Тест доступности сервисов под ТСПУ
echo ===============================================================================
echo [1] Проверка YouTube (www.youtube.com)...
powershell -NoProfile -Command "$r = try { (Invoke-WebRequest -Uri 'https://www.youtube.com' -UseBasicParsing -TimeoutSec 5).StatusCode } catch { 0 }; if ($r -eq 200) { Write-Host ' [OK] YouTube: ДОСТУПЕН (HTTP 200)' -ForegroundColor Green } else { Write-Host ' [X] YouTube: НЕДОСТУПЕН' -ForegroundColor Red }"

echo [2] Проверка Discord (discord.com)...
powershell -NoProfile -Command "$r = try { (Invoke-WebRequest -Uri 'https://discord.com' -UseBasicParsing -TimeoutSec 5).StatusCode } catch { 0 }; if ($r -eq 200) { Write-Host ' [OK] Discord: ДОСТУПЕН (HTTP 200)' -ForegroundColor Green } else { Write-Host ' [X] Discord: НЕДОСТУПЕН' -ForegroundColor Red }"

echo [3] Проверка RuTracker (rutracker.org)...
powershell -NoProfile -Command "$r = try { (Invoke-WebRequest -Uri 'https://rutracker.org' -UseBasicParsing -TimeoutSec 5).StatusCode } catch { 0 }; if ($r -eq 200) { Write-Host ' [OK] RuTracker: ДОСТУПЕН (HTTP 200)' -ForegroundColor Green } else { Write-Host ' [X] RuTracker: НЕДОСТУПЕН' -ForegroundColor Red }"
echo.
pause
goto MENU

:QUIT
exit /b
