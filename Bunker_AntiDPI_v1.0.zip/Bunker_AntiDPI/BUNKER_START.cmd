@echo off
setlocal EnableDelayedExpansion
chcp 65001 > nul
title BUNKER ANTI-DPI v1.0 [KOT ANTIDOT]
color 0B

:: Проверка прав администратора
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Требуются права Администратора... Запуск от имени Администратора...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath cmd.exe -ArgumentList '/k ""%~f0""' -Verb RunAs"
    exit /b
)

:: Переходим в корень папки скрипта
pushd "%~dp0"
set "ROOT=%~dp0"
set "SRVCNAME=BunkerAntiDPI"

:MENU
cls
echo ===============================================================================
echo   🐈‍⬛ BUNKER ANTI-DPI v1.0  —  ОБХОД БЛОКИРОВОК ТСПУ БЕЗ VPN
echo ===============================================================================
echo   Разработано: @k0tlux (KOT ANTIDOT)  •  Сообщество: @BUNKER_KOTA
echo   Поддержка: YouTube 4K 60fps, Discord (Голос/Видео/Медиа), Сайты
echo ===============================================================================
echo.
echo   [1] 🚀 ЗАПУСТИТЬ В 1 КЛИК (Режим «Ультра» — YouTube 4K + Discord Голос)
echo   [2] 🔄 ЗАПУСТИТЬ АЛЬТЕРНАТИВНЫЙ (Для жестких провайдеров: Ростелеком, SevStar)
echo   [3] ⚙️ УСТАНОВИТЬ В СЛУЖБЫ WINDOWS (Тихий автозапуск без открытых окон)
echo   [4] 🛑 ОСТАНОВИТЬ ВСЕ ПРОЦЕССЫ И СЛУЖБУ
echo   [5] 🩺 ПРОВЕРИТЬ СВЯЗЬ С YOUTUBE И DISCORD
echo   [0] ❌ ВЫХОД
echo.
echo ===============================================================================
set /p choice="Выберите действие [0-5]: "

if "%choice%"=="1" goto START_ULTRA
if "%choice%"=="2" goto START_ALT
if "%choice%"=="3" goto INSTALL_SERVICE
if "%choice%"=="4" goto STOP_ALL
if "%choice%"=="5" goto TEST_CONNECTION
if "%choice%"=="0" goto QUIT
goto MENU

:START_ULTRA
cls
echo [i] Остановка предыдущих процессов winws...
taskkill /F /IM winws.exe >nul 2>&1
echo [i] Запуск Bunker Anti-DPI (Режим Ультра)...
echo.
echo [!] НЕ ЗАКРЫВАЙТЕ ЭТО ОКНО! Сверните его во время использования.
echo.
pushd "%ROOT%bin"
start "Bunker Anti-DPI [Ultra]" /min winws.exe --wf-tcp=80,443,2053,2083,2087,2096,8443 --wf-udp=443,19294-19344,50000-50100 --filter-udp=443 --hostlist="..\lists\list-general.txt" --dpi-desync=fake --dpi-desync-repeats=11 --dpi-desync-fake-quic="quic_initial_www_google_com.bin" --new --filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-fake-discord="ACTIVE_DISCORD_UDP.bin" --dpi-desync-fake-stun="ACTIVE_DISCORD_UDP.bin" --dpi-desync-repeats=6 --new --filter-tcp=2053,2083,2087,2096,8443 --hostlist-domains=discord.media --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=681 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern="tls_clienthello_www_google_com.bin" --dpi-desync-fake-tls="tls_clienthello_www_google_com.bin" --new --filter-tcp=443 --hostlist="..\lists\list-google.txt" --ip-id=zero --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=681 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern="tls_clienthello_www_google_com.bin" --dpi-desync-fake-tls="tls_clienthello_www_google_com.bin" --new --filter-tcp=80,443 --hostlist="..\lists\list-general.txt" --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=664 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern="tls_clienthello_www_sferum_ru.bin" --dpi-desync-fake-tls="stun2.bin" --dpi-desync-fake-tls="tls_clienthello_www_sferum_ru.bin" --dpi-desync-fake-http="tls_clienthello_www_sferum_ru.bin"
popd
echo [✓] Обход активирован в фоновом окне! Проверьте YouTube и Discord.
echo.
pause
goto MENU

:START_ALT
cls
echo [i] Остановка предыдущих процессов winws...
taskkill /F /IM winws.exe >nul 2>&1
echo [i] Запуск Bunker Anti-DPI (Альтернативный режим Multisplit)...
echo.
echo [!] НЕ ЗАКРЫВАЙТЕ ЭТО ОКНО! Сверните его во время использования.
echo.
pushd "%ROOT%bin"
start "Bunker Anti-DPI [Alt]" /min winws.exe --wf-tcp=80,443,2053,2083,2087,2096,8443 --wf-udp=443,19294-19344,50000-50100 --filter-udp=443 --hostlist="..\lists\list-general.txt" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-quic="quic_initial_www_google_com.bin" --new --filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-fake-discord="ACTIVE_DISCORD_UDP.bin" --dpi-desync-repeats=6 --new --filter-tcp=443 --hostlist="..\lists\list-google.txt" --dpi-desync=multisplit --dpi-desync-split-seqovl=681 --dpi-desync-split-pos=1 --dpi-desync-split-seqovl-pattern="tls_clienthello_www_google_com.bin" --new --filter-tcp=80,443 --hostlist="..\lists\list-general.txt" --dpi-desync=multisplit --dpi-desync-split-seqovl=568 --dpi-desync-split-pos=1 --dpi-desync-split-seqovl-pattern="tls_clienthello_4pda_to.bin"
popd
echo [✓] Альтернативный обход активирован!
echo.
pause
goto MENU

:INSTALL_SERVICE
cls
echo ===============================================================================
echo   Установка службы Windows «%SRVCNAME%»
echo ===============================================================================
echo [i] Остановка старых служб и процессов...
net stop %SRVCNAME% >nul 2>&1
sc delete %SRVCNAME% >nul 2>&1
taskkill /F /IM winws.exe >nul 2>&1

set "BIN_EXE=%ROOT%bin\winws.exe"
set "BIN_DIR=%ROOT%bin"
set "LIST_GEN=%ROOT%lists\list-general.txt"
set "LIST_GOOG=%ROOT%lists\list-google.txt"
set "FAKE_QUIC=%ROOT%bin\quic_initial_www_google_com.bin"
set "FAKE_DISC=%ROOT%bin\ACTIVE_DISCORD_UDP.bin"
set "FAKE_TLS=%ROOT%bin	ls_clienthello_www_google_com.bin"
set "FAKE_SFER=%ROOT%bin	ls_clienthello_www_sferum_ru.bin"
set "FAKE_STUN=%ROOT%bin\stun2.bin"

echo [i] Создание службы Windows...
sc create %SRVCNAME% binPath= ""%BIN_EXE%" --wf-tcp=80,443,2053,2083,2087,2096,8443 --wf-udp=443,19294-19344,50000-50100 --filter-udp=443 --hostlist="%LIST_GEN%" --dpi-desync=fake --dpi-desync-repeats=11 --dpi-desync-fake-quic="%FAKE_QUIC%" --new --filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-fake-discord="%FAKE_DISC%" --dpi-desync-repeats=6 --new --filter-tcp=443 --hostlist="%LIST_GOOG%" --ip-id=zero --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=681 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern="%FAKE_TLS%" --dpi-desync-fake-tls="%FAKE_TLS%" --new --filter-tcp=80,443 --hostlist="%LIST_GEN%" --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=664 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern="%FAKE_SFER%" --dpi-desync-fake-tls="%FAKE_STUN%"" DisplayName= "Bunker Anti-DPI Service" start= auto
sc description %SRVCNAME% "Фоновый обход блокировок ТСПУ для YouTube и Discord от Бункера Кота (@BUNKER_KOTA)"
sc start %SRVCNAME%

echo.
echo [✓] Служба «%SRVCNAME%» успешно установлена и запущена!
echo [i] Теперь обход будет работать автоматически при каждом включении ПК.
echo.
pause
goto MENU

:STOP_ALL
cls
echo [i] Остановка всех процессов и служб...
net stop %SRVCNAME% >nul 2>&1
sc delete %SRVCNAME% >nul 2>&1
net stop WinDivert >nul 2>&1
sc delete WinDivert >nul 2>&1
net stop WinDivert14 >nul 2>&1
sc delete WinDivert14 >nul 2>&1
taskkill /F /IM winws.exe >nul 2>&1
echo [✓] Все процессы Bunker Anti-DPI и служба успешно остановлены.
pause
goto MENU

:TEST_CONNECTION
cls
echo ===============================================================================
echo   Тест доступности сервисов под ТСПУ
echo ===============================================================================
echo [1] Проверка YouTube (www.youtube.com)...
powershell -NoProfile -Command "try {  = Invoke-WebRequest -Uri 'https://www.youtube.com' -UseBasicParsing -TimeoutSec 5; Write-Host ' [✓] YouTube: ОК (HTTP ' .StatusCode ')' -ForegroundColor Green } catch { Write-Host ' [X] YouTube: ОШИБКА (' bash.Exception.Message ')' -ForegroundColor Red }"

echo [2] Проверка Discord API...
powershell -NoProfile -Command "try {  = Invoke-WebRequest -Uri 'https://discord.com' -UseBasicParsing -TimeoutSec 5; Write-Host ' [✓] Discord: ОК (HTTP ' .StatusCode ')' -ForegroundColor Green } catch { Write-Host ' [X] Discord: ОШИБКА (' bash.Exception.Message ')' -ForegroundColor Red }"

echo [3] Проверка заблокированных ресурсов...
powershell -NoProfile -Command "try {  = Invoke-WebRequest -Uri 'https://rutracker.org' -UseBasicParsing -TimeoutSec 5; Write-Host ' [✓] RuTracker: ОК (HTTP ' .StatusCode ')' -ForegroundColor Green } catch { Write-Host ' [X] RuTracker: ОШИБКА (' bash.Exception.Message ')' -ForegroundColor Red }"
echo.
pause
goto MENU

:QUIT
popd
exit /b
