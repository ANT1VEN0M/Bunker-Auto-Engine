@echo off
title BUNKER ANTI-DPI v1.0 [KOT ANTIDOT]
chcp 65001 > nul
color 0B

:: -----------------------------------------------------------------------------
:: Проверка прав администратора и авто-элевация
:: -----------------------------------------------------------------------------
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [i] Требуются права Администратора... Запрашиваю UAC...
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

cd /d "%~dp0"
set "BIN=%~dp0bin\"
set "LISTS=%~dp0lists\"
set "SRVCNAME=BunkerAntiDPI"

:MENU
cls
echo ===============================================================================
echo   🐈‍⬛ BUNKER ANTI-DPI v1.0  —  ОБХОД БЛОКИРОВОК ТСПУ БЕЗ VPN
echo ===============================================================================
echo   Разработано: @k0tlux (KOT ANTIDOT)  •  Сообщество: @BUNKER_KOTA
echo   Поддержка: YouTube 4K 60fps, Discord (Голос/Видео/Медиа), Сайты
echo ===============================================================================
echo.
echo   [1] 🚀 ЗАПУСТИТЬ В 1 КЛИК (Режим «Ультра» — YouTube 4K + Discord Голос)
echo   [2] 🔄 ЗАПУСТИТЬ АЛЬТЕРНАТИВНЫЙ (Для жестких провайдеров: Ростелеком, Дом.ru)
echo   [3] ⚙️ УСТАНОВИТЬ В СЛУЖБЫ WINDOWS (Тихий автозапуск без открытых окон)
echo   [4] 🛑 ОСТАНОВИТЬ ВСЕ ПРОЦЕССЫ И СЛУЖБУ
echo   [5] 🩺 ПРОВЕРИТЬ СВЯЗЬ С YOUTUBE И DISCORD
echo   [0] ❌ ВЫХОД
echo.
echo ===============================================================================
set /p choice="Выберите действие [0-5]: "

if "%choice%"=="1" goto START_ULTRA
if "%choice%"=="2" goto START_ALT
if "%choice%"=="3" goto INSTALL_SERVICE
if "%choice%"=="4" goto STOP_ALL
if "%choice%"=="5" goto TEST_CONNECTION
if "%choice%"=="0" exit /b
goto MENU

:START_ULTRA
cls
echo [i] Останавливаем предыдущие процессы...
taskkill /F /IM winws.exe >nul 2>&1
echo [i] Запуск Bunker Anti-DPI (Режим Ультра)...
echo.
echo [!] НЕ ЗАКРЫВАЙТЕ ЭТО ОКНО ВО ВРЕМЯ РАБОТЫ! (Сверните его)
echo.
start "Bunker Anti-DPI [Ultra]" /min "%BIN%winws.exe" --wf-tcp=80,443,2053,2083,2087,2096,8443 --wf-udp=443,19294-19344,50000-50100 ^
--filter-udp=443 --hostlist="%LISTS%list-general.txt" --dpi-desync=fake --dpi-desync-repeats=11 --dpi-desync-fake-quic="%BIN%quic_initial_www_google_com.bin" --new ^
--filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-fake-discord="%BIN%ACTIVE_DISCORD_UDP.bin" --dpi-desync-fake-stun="%BIN%ACTIVE_DISCORD_UDP.bin" --dpi-desync-repeats=6 --new ^
--filter-tcp=2053,2083,2087,2096,8443 --hostlist-domains=discord.media --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=681 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern="%BIN%tls_clienthello_www_google_com.bin" --dpi-desync-fake-tls="%BIN%tls_clienthello_www_google_com.bin" --new ^
--filter-tcp=443 --hostlist="%LISTS%list-google.txt" --ip-id=zero --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=681 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern="%BIN%tls_clienthello_www_google_com.bin" --dpi-desync-fake-tls="%BIN%tls_clienthello_www_google_com.bin" --new ^
--filter-tcp=80,443 --hostlist="%LISTS%list-general.txt" --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=664 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern="%BIN%tls_clienthello_www_sferum_ru.bin" --dpi-desync-fake-tls="%BIN%stun2.bin" --dpi-desync-fake-tls="%BIN%tls_clienthello_www_sferum_ru.bin" --dpi-desync-fake-http="%BIN%tls_clienthello_www_sferum_ru.bin"
echo [✓] Обход активирован в фоновом окне! Проверьте YouTube в браузере.
pause
goto MENU

:START_ALT
cls
echo [i] Останавливаем предыдущие процессы...
taskkill /F /IM winws.exe >nul 2>&1
echo [i] Запуск Bunker Anti-DPI (Альтернативный режим Multisplit)...
echo.
start "Bunker Anti-DPI [Alt]" /min "%BIN%winws.exe" --wf-tcp=80,443,2053,2083,2087,2096,8443 --wf-udp=443,19294-19344,50000-50100 ^
--filter-udp=443 --hostlist="%LISTS%list-general.txt" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-quic="%BIN%quic_initial_www_google_com.bin" --new ^
--filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-fake-discord="%BIN%ACTIVE_DISCORD_UDP.bin" --dpi-desync-repeats=6 --new ^
--filter-tcp=443 --hostlist="%LISTS%list-google.txt" --dpi-desync=multisplit --dpi-desync-split-seqovl=681 --dpi-desync-split-pos=1 --dpi-desync-split-seqovl-pattern="%BIN%tls_clienthello_www_google_com.bin" --new ^
--filter-tcp=80,443 --hostlist="%LISTS%list-general.txt" --dpi-desync=multisplit --dpi-desync-split-seqovl=568 --dpi-desync-split-pos=1 --dpi-desync-split-seqovl-pattern="%BIN%tls_clienthello_4pda_to.bin"
echo [✓] Альтернативный обход активирован!
pause
goto MENU

:INSTALL_SERVICE
cls
echo ===============================================================================
echo   Установка службы Windows «%SRVCNAME%»
echo ===============================================================================
echo [i] Остановка старых служб и процессов...
net stop %SRVCNAME% >nul 2>&1
sc delete %SRVCNAME% >nul 2>&1
taskkill /F /IM winws.exe >nul 2>&1

set "WINWS_BIN=%BIN%winws.exe"
set "ARGS=--wf-tcp=80,443,2053,2083,2087,2096,8443 --wf-udp=443,19294-19344,50000-50100 --filter-udp=443 --hostlist=\"%LISTS%list-general.txt\" --dpi-desync=fake --dpi-desync-repeats=11 --dpi-desync-fake-quic=\"%BIN%quic_initial_www_google_com.bin\" --new --filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-fake-discord=\"%BIN%ACTIVE_DISCORD_UDP.bin\" --dpi-desync-repeats=6 --new --filter-tcp=443 --hostlist=\"%LISTS%list-google.txt\" --ip-id=zero --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=681 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern=\"%BIN%tls_clienthello_www_google_com.bin\" --dpi-desync-fake-tls=\"%BIN%tls_clienthello_www_google_com.bin\" --new --filter-tcp=80,443 --hostlist=\"%LISTS%list-general.txt\" --dpi-desync=fake,multisplit --dpi-desync-split-seqovl=664 --dpi-desync-split-pos=1 --dpi-desync-fooling=ts --dpi-desync-repeats=8 --dpi-desync-split-seqovl-pattern=\"%BIN%tls_clienthello_www_sferum_ru.bin\" --dpi-desync-fake-tls=\"%BIN%stun2.bin\""

echo [i] Создание службы Windows...
sc create %SRVCNAME% binPath= "\"%WINWS_BIN%\" %ARGS%" DisplayName= "Bunker Anti-DPI Service" start= auto
sc description %SRVCNAME% "Фоновый обход блокировок ТСПУ для YouTube и Discord от Бункера Кота (@BUNKER_KOTA)"
sc start %SRVCNAME%

echo.
echo [✓] Служба «%SRVCNAME%» успешно установлена и запущена!
echo [i] Теперь обход будет работать автоматически при каждом включении ПК без лишних окон.
echo.
pause
goto MENU

:STOP_ALL
cls
echo [i] Остановка всех процессов и служб...
net stop %SRVCNAME% >nul 2>&1
sc delete %SRVCNAME% >nul 2>&1
net stop WinDivert >nul 2>&1
sc delete WinDivert >nul 2>&1
net stop WinDivert14 >nul 2>&1
sc delete WinDivert14 >nul 2>&1
taskkill /F /IM winws.exe >nul 2>&1
echo [✓] Все процессы Bunker Anti-DPI и драйвер WinDivert успешно остановлены.
pause
goto MENU

:TEST_CONNECTION
cls
echo ===============================================================================
echo   Тест доступности сервисов под ТСПУ
echo ===============================================================================
echo [1] Проверка YouTube (googlevideo.com)...
powershell -Command "try { $res = Invoke-WebRequest -Uri 'https://www.youtube.com' -UseBasicParsing -TimeoutSec 5; Write-Host ' [✓] YouTube: ОК (HTTP ' $res.StatusCode ')' -ForegroundColor Green } catch { Write-Host ' [X] YouTube: ОШИБКА (' $_.Exception.Message ')' -ForegroundColor Red }"

echo [2] Проверка Discord API...
powershell -Command "try { $res = Invoke-WebRequest -Uri 'https://discord.com' -UseBasicParsing -TimeoutSec 5; Write-Host ' [✓] Discord: ОК (HTTP ' $res.StatusCode ')' -ForegroundColor Green } catch { Write-Host ' [X] Discord: ОШИБКА (' $_.Exception.Message ')' -ForegroundColor Red }"

echo [3] Проверка заблокированных ресурсов...
powershell -Command "try { $res = Invoke-WebRequest -Uri 'https://rutracker.org' -UseBasicParsing -TimeoutSec 5; Write-Host ' [✓] RuTracker: ОК (HTTP ' $res.StatusCode ')' -ForegroundColor Green } catch { Write-Host ' [X] RuTracker: ОШИБКА (' $_.Exception.Message ')' -ForegroundColor Red }"
echo.
pause
goto MENU
