@echo off
setlocal
chcp 65001 > nul
title Удаление службы Bunker Anti-DPI

net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [!] Требуются права Администратора...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

set "SRVCNAME=BunkerAntiDPI"
echo [i] Остановка и удаление службы %SRVCNAME%...
net stop %SRVCNAME% >nul 2>&1
sc delete %SRVCNAME% >nul 2>&1
net stop WinDivert >nul 2>&1
sc delete WinDivert >nul 2>&1
net stop WinDivert14 >nul 2>&1
sc delete WinDivert14 >nul 2>&1
taskkill /F /IM winws.exe >nul 2>&1

echo.
echo ===============================================================================
echo [OK] Служба и все процессы Bunker Anti-DPI полностью остановлены и удалены.
echo ===============================================================================
echo.
pause
